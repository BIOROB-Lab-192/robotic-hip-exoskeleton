/*
 * rtmodel.h
 *
 * Code generation for Simulink model "emg_Original".
 *
 * Simulink Coder version                : 23.2 (R2023b) 01-Aug-2023
 * C source code generated on : Fri Apr 18 11:57:44 2025
 *
 * Note that the generated code is not dependent on this header file.
 * The file is used in cojuction with the automatic build procedure.
 * It is included by the sample main executable harness
 * MATLAB/rtw/c/src/common/rt_main.c.
 *
 */

#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "emg_Original.h"
#endif                                 /* RTW_HEADER_rtmodel_h_ */
